module cs380.NYTSpellingBee {
    requires javafx.controls;
    exports cs380.NYTSpellingBee;
}
